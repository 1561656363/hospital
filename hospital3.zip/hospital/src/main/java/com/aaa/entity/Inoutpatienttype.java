package com.aaa.entity;


public class Inoutpatienttype {
    private Integer inoutpatientId;
    private String projectName;
    private String pprojectName;
    private double price;
    private Integer bigprojectId;
    private Integer projectId;
    private Integer unit;
    private Integer unitId;
    private String unitName;

    public Integer getUnitId() {
        return unitId;
    }

    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getPprojectName() {
        return pprojectName;
    }

    public void setPprojectName(String pprojectName) {
        this.pprojectName = pprojectName;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public Integer getBigprojectId() {
        return bigprojectId;
    }

    public void setBigprojectId(Integer bigprojectId) {
        this.bigprojectId = bigprojectId;
    }

    public Integer getUnit() {
        return unit;
    }

    public void setUnit(Integer unit) {
        this.unit = unit;
    }

    public Integer getInoutpatientId() {
        return inoutpatientId;
    }

    public void setInoutpatientId(Integer inoutpatientId) {
        this.inoutpatientId = inoutpatientId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
