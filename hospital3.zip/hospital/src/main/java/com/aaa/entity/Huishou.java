package com.aaa.entity;

public class Huishou {
   private Integer huishouid ;
    private String huishouname ;
    private Integer huishounumber ;
    private String  huishoupihao ;
    private String   jbr ;
    private String beizhu ;

    public Integer getHuishouid() {
        return huishouid;
    }

    public void setHuishouid(Integer huishouid) {
        this.huishouid = huishouid;
    }

    public String getHuishouname() {
        return huishouname;
    }

    public void setHuishouname(String huishouname) {
        this.huishouname = huishouname;
    }

    public Integer getHuishounumber() {
        return huishounumber;
    }

    public void setHuishounumber(Integer huishounumber) {
        this.huishounumber = huishounumber;
    }

    public String getHuishoupihao() {
        return huishoupihao;
    }

    public void setHuishoupihao(String huishoupihao) {
        this.huishoupihao = huishoupihao;
    }

    public String getJbr() {
        return jbr;
    }

    public void setJbr(String jbr) {
        this.jbr = jbr;
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }
}
