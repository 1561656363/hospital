package com.aaa.service;

import com.aaa.entity.Litem;
import com.aaa.entity.Lrecord;

import java.util.List;

public interface LitemService {

    List<Litem> selItems(Litem litem);
}
